package com.example.travels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.travels.model.Intercity;

public interface IntercityRepository  extends JpaRepository<Intercity, String>{

}
